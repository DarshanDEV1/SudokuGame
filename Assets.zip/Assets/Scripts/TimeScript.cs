using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TimeScript : MonoBehaviour
{
    [SerializeField] private float _timeTaken = 0;
    [SerializeField] private TMP_Text _timeText;
    [SerializeField] private float _timeMinute;
    [SerializeField] private float _timeSecond;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        _TimeTakenToSolve();
    }

    public void _TimeTakenToSolve()
    {
        _timeTaken += UnityEngine.Time.deltaTime;
        //_timeText.text = "Time : " + ((int)_timeTaken).ToString();
        _timeMinute = _timeTaken / 60;
        _timeSecond = _timeTaken % 60;

        //_timeText.text = "Time : " + string.Format("{0:00} : {1:00}", _timeMinute, _timeSecond);
        _timeText.text = "Time : " + ((int)_timeTaken).ToString();
    }
}
