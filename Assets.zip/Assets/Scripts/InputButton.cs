﻿using UnityEngine;


public class InputButton : MonoBehaviour
{
    public static InputButton instance;
    SudokuCell lastCell;
    [SerializeField] GameObject wrongText;
    [SerializeField] private GameManager _gm;
    int row;
    int col;
    [SerializeField] private Board board;

    private void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        this.gameObject.SetActive(false);
        //_gm = GameObject.Find("GameManager").GetComponent<GameManager>();
    }

    public void ActivateInputButton(SudokuCell cell, int row, int col)
    {
        this.gameObject.SetActive(true);
        lastCell= cell;
        this.row = row;
        this.col = col;
    }

    //InputButtonClicked
    public void ClickedButton(int num)
    {
        lastCell.UpdateValue(num);
        Debug.Log(lastCell + "  " + row.ToString() + "  " + col.ToString());
        board.Check(row, col);
        //board.AgainCheck(row, col);
        wrongText.SetActive(false);
        this.gameObject.SetActive(false);
    }
}
