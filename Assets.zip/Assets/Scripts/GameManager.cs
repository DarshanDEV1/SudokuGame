﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;
using System.Collections;

interface PlayerMethods
{
    abstract void Start();
    abstract void Update();
    abstract void _On_Click_NextScene();
    abstract void _On_Click_PrevScene();
    //abstract void _OnClick_DeletePlayerPrefs();
    abstract void _OnClick_ExitApplication();
    abstract void _OnClick_RestartScene();
    //abstract void _SelectDifficultyController();
    //abstract void _OnClick_ExitApplicationConfig();
    //abstract void _OnClickNo();
    //abstract void _TimeTakenToSolve();
    abstract void _OnClickDivertToTutorialDocs();
}

public class GameManager : MonoBehaviour, PlayerMethods
{

    public Text TextLevel;
    public TMP_Text TextLevelWin;
    [SerializeField] private TMP_Text _level;

    [SerializeField] private TMP_Text _level_Txt;
    //private float _timeTaken = 0;
    [SerializeField] private TMP_Text _timeText;
    //private float _timeMinute;
    //private float _timeSecond;
    //Back tracking using stack data structure is to be implemented.
    public Stack _stack;
    //public Board _board;
    //public static GameManager instance;

    //private void Awake()
    //{
    //    if (this == null)
    //    {
    //        instance = this;
    //    }
    //}

    public void Start()
    {
        
        UpdateText();
        
    }

    public void Update()
    {
        //_TimeTakenToSolve();
    }
    public void _On_Click_NextScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void _On_Click_PrevScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }
    public void _OnClick_RestartScene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        //_timeTaken = 0;
    }
    
    public void _OnClick_ExitApplication()
    {
        Application.Quit();
    }
    
    
    
    private void UpdateText()
    {
        var _v = PlayerPrefs.GetInt("_level");
        if(_v == 15)
        {
            //
            //_level_Txt.text = "Level : Noob";
        }
        if(_v == 35)
        {
            //
            ////_level_Txt.text = "Level : Beginner";
        }
        if(_v == 55)
        {
            //
            ////_level_Txt.text = "Level : Intermediate";
        }
        if(_v == 75)
        {
            //
            ////_level_Txt.text = "Level : Expert";
        }
    }

    //public void _TimeTakenToSolve()
    //{
    //    _timeTaken += UnityEngine.Time.deltaTime;
    //    //_timeText.text = "Time : " + ((int)_timeTaken).ToString();
    //    _timeMinute = _timeTaken / 60;
    //    _timeSecond = _timeTaken % 60;

    //    _timeText.text = "Time : " + string.Format("{0:00} : {1:00}", _timeMinute, _timeSecond);
    //}
    public void _OnClickDivertToTutorialDocs()
    {
        Application.OpenURL("https://sudoku.com/how-to-play/sudoku-rules-for-complete-beginners/");
    }
}
