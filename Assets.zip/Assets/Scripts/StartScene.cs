using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StartScene : MonoBehaviour
{
    [SerializeField] private GameObject _ConfigPanel;
    [SerializeField] private GameObject _MainPanel;
    [SerializeField] private TMP_Dropdown _drop_down;
    // Start is called before the first frame update
    void Start()
    {
        var _v = PlayerPrefs.GetInt("_level");
        //Debug.Log(_v);
        //_level.text = "Level : " + _v.ToString();
        //if(_v == 1)
        //{
        //    _drop_down.value = 0;
        //}
        //_ConfigPanel.SetActive(false);
        
        if(_v == 15)
        {
            //
            _drop_down.value = 0;
            //_level_Txt.text = "Level : Noob";
        }
        if(_v == 35)
        {
            //
            _drop_down.value = 1;
            //_level_Txt.text = "Level : Beginner";
        }
        if(_v == 55)
        {
            //
            _drop_down.value = 2;
            //_level_Txt.text = "Level : Intermediate";
        }
        if(_v == 75)
        {
            //
            _drop_down.value = 3;
            //_level_Txt.text = "Level : Expert";
        }
        _MainPanel.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void _OnClick_ExitApplicationConfig()
    {
        _ConfigPanel.SetActive(true);
        _MainPanel.SetActive(false);
    }
    public void _OnClickNo()
    {
        _ConfigPanel.SetActive(false);
        _MainPanel.SetActive(true);
    }
    public void _OnClick_DeletePlayerPrefs()
    {
        PlayerPrefs.DeleteAll();
        //PlayerPrefs.SetInt("_level", 0);
        PlayerPrefs.SetInt("_level", 15);
        var _l = PlayerPrefs.GetInt("_level");
        _drop_down.value = 0;
        //_level.text = "Level : " + _l.ToString();
    }
    public void _SelectDifficultyController()
    {
        int _value = _drop_down.value;
        if(_value == 0)
        {
            //Difficulty level is from 0-15
            PlayerPrefs.SetInt("_level", 15);//UnityEngine.Random.Range(0, 15);
        }
        if(_value == 1)
        {
            //Difficulty level is from 16-35
            PlayerPrefs.SetInt("_level", 35);//UnityEngine.Random.Range(16, 35);
        }
        if(_value == 2)
        {
            //Difficulty level is from 36-55
            PlayerPrefs.SetInt("_level", 55);//UnityEngine.Random.Range(36, 55);
        }
        if(_value == 3)
        {
            //Difficulty level is from 56-75
            PlayerPrefs.SetInt("_level", 75);//UnityEngine.Random.Range(56, 75);
        }
    }
}
