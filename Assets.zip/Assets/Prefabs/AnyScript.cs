using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnyScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //void CreatePuzzle()
    //{
    //    System.Array.Copy(grid, puzzle, grid.Length);

    //    //Getting level of the player
    //    var _difficultyLevel = PlayerPrefs.GetInt("_level");
    //    // Remove cells
    //    for (int i = 0; i < _difficultyLevel; i++)
    //    {
    //        int row = Random.Range(0, 9);
    //        int col = Random.Range(0, 9);

    //        while (puzzle[row,col] == 0)
    //        {
    //            row = Random.Range(0, 9);
    //            col = Random.Range(0, 9);
    //        }

    //        puzzle[row, col] = 0;
    //    }

    //    List<int> onBoard = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    //    _RandomList(onBoard);

    //    for (int i = 0; i < 9; i++)
    //    {
    //        for (int j = 0; j < 9; j++)
    //        {
    //            for (int k = 0; k < onBoard.Count - 1; k++)
    //            {
    //                if (onBoard[k] == puzzle[i,j])
    //                {
    //                    onBoard.RemoveAt(k);
    //                }
    //            }
    //        }
    //    }

    //    while (onBoard.Count - 1 > 1)
    //    {
    //        int row = Random.Range(0, 9);
    //        int col = Random.Range(0, 9);

    //        if (grid[row,col] == onBoard[0])
    //        {
    //            puzzle[row, col] = grid[row, col];
    //            onBoard.RemoveAt(0);
    //        }

    //    }

    //    //ConsoleOutputGrid(puzzle);

    //}

    
    //void ConsoleOutputGrid(int [,] g)
    //{
    //    string output = "";
    //    for (int i = 0; i < 9; i++)
    //    {
    //        for (int j = 0; j < 9; j++)
    //        {
    //            output += g[i, j];
    //        }
    //        output += "\n";
    //    }
    //}

    //if(Check())
        //{
        //    if (CheckGrid())
        //    {
        //        winMenu.SetActive(true);
        //        int _var = PlayerPrefs.GetInt("_level");
        //        _var++;
        //        PlayerPrefs.SetInt("_level", _var);
        //    }
        //}

    //    void _RandomList(List<int> l)
    //{
    //    for (var i = 0; i < l.Count - 1; i++)
    //    {
    //        int rand = Random.Range(i, l.Count);
    //        int temp = l[i];
    //        l[i] = l[rand];
    //        l[rand] = temp;
    //    }
    //}

    //    public void _RandomList(List<int> l)
    //{
    //    for (var i = 0; i < l.Count - 1; i++)
    //    {
    //        int rand = Random.Range(i, l.Count);
    //        int temp = l[i];
    //        l[i] = l[rand];
    //        l[rand] = temp;
    //    }
    //}

    //Create puzzle while loop
                //while (puzzle[row, col] == 0)
            //{
            //    row = Random.Range(0, 9);
            //    col = Random.Range(0, 9);
            //}

    //Create puzzle confusing statement
        //List<int> onBoard = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        //_RandomList(onBoard);

        ////This list refines all the numbers that are not presented in the puzzle array
        //for (int i = 0; i < 9; i++)
        //{
        //    for (int j = 0; j < 9; j++)
        //    {
        //        for (int k = 0; k < onBoard.Count - 1; k++)
        //        {
        //            if (onBoard[k] == puzzle[i, j])
        //            {
        //                onBoard.RemoveAt(k);
        //            }
        //        }
        //    }
        //}

        ////This assigns the value to the puzzle array if the number of elements not presented in that 2d array is greater than 1 and removes.
        //while (onBoard.Count - 1 > 1)
        //{
        //    int row = Random.Range(0, 9);
        //    int col = Random.Range(0, 9);

        //    if (grid[row, col] == onBoard[0])
        //    {
        //        puzzle[row, col] = grid[row, col];
        //        onBoard.RemoveAt(0);
        //    }

        //}

        //ConsoleOutputGrid(puzzle);
}
