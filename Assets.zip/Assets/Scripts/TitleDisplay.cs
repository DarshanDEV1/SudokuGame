using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class TitleDisplay : MonoBehaviour
{
    [SerializeField] private GameObject[] _titles;
    [SerializeField] private bool _canActive = false;
    [SerializeField] private GameObject _mainPanel;

    // Start is called before the first frame update
    void Start()
    {
        //_mainPanel.SetActive(false);
        StartCoroutine(enumerator());
    }
    
    // Update is called once per frame
    void Update()
    {
        if(_canActive == true)
        {
            //_mainPanel.SetActive(true);
        }
    }

    IEnumerator enumerator()
    {
        yield return new WaitForSeconds(0.3f);
        for(int i = 0; i < _titles.Length; i ++)
        {
            yield return new WaitForSeconds(1);
            _titles[i].SetActive(true);
            for(int j = 0; j < _titles.Length; j ++)
            {
                if(j != i)
                {
                    //Do something
                    _titles[j].SetActive(false);
                }
            }
        }
        yield return new WaitForSeconds(0.5f);
        _canActive = true;
    }
}
