using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.IO;

public class SaveNLoadGame : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        //SD();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void SD()
    {
        Board _b = new Board();

        FileInfo fi = new FileInfo("Assets/savedData.txt");
        FileStream fs = fi.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
        StreamWriter sw = new StreamWriter(fs);
        for(int i = 0; i < 9; i ++)
        {
            for(int j = 0; j < 9; j ++)
            {
                sw.Write(_b.puzzle[i, j]);
            }
        }
        StreamReader sr = new StreamReader(fs);
        string fileContent = sr.ReadToEnd();
        sr.Close();
        fs.Close();
        //Debug.Log(fileContent);
    }
}
