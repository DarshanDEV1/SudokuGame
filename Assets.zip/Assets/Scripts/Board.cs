﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;
using System.IO;
using System.Linq;

interface PlayerGameFunction
{
    abstract void _CreateGrid();
    abstract void Update();
    abstract void Start();
    abstract bool _ColumnContainsValue(int col, int value);
    abstract bool _RowContainsValue(int row, int value);
    abstract bool _SquareContainsValue(int row, int col, int value);
    abstract bool _CheckAll(int row, int col, int value);
    abstract bool _IsValid();
    abstract bool _CreateLevel();
    abstract void _CreateButtons();
    abstract void _UpdatePuzzle(int row, int col, int value);
    abstract void _CheckComplete();
    abstract void _Wait();
    abstract bool _CheckGrid();
    abstract void _CreatePuzzle();
    //abstract void _UnityEngine.RandomList(List<int> _l);

}

[Serializable]
public class SaveData
{
    public int[,] dt_config = new int[9, 9];
}
public class Board : MonoBehaviour, PlayerGameFunction
{
    // Create the intital Sudoku Grid
    public int[,] grid = new int[9,9];
    public int[,] puzzle = new int[9, 9];
    //int[,] dt_config = new int[9, 9];

    public Transform square00, square01, square02, 
                     square10, square11, square12, 
                     square20, square21, square22;
    public GameObject SudokuCell_Prefab;
    public GameObject winMenu;
    [SerializeField] private GameObject loseText;
    [SerializeField] private GameObject inputButtons;
    [SerializeField] private GameObject _nBtn;
    [SerializeField] private SudokuCell _sCell;
    [SerializeField] private GameObject[] _indicators;
    [SerializeField] private List<int> _integers;
    [SerializeField] private List<string> _cords;
    [SerializeField] private int[] _count;
    [SerializeField] private GameObject _winText;
    [SerializeField] private List<int> _gridValues;
    [SerializeField] private List<int> _puzzleValues;

    //[SerializeField] private List<int> _config;
    //public int _difficultyLevel;

    public void Start()
    {
        _count = new int[9];

        _winText.SetActive(false);
        winMenu.SetActive(false);
        var _v = PlayerPrefs.GetInt("_isLoading");

        if(_v == 0)
        {
            _CreateGrid();//Assigns values to the buttons
            _CreateLevel();
            _CreatePuzzle();
        }
        else
        {
            FileInfo fi = new FileInfo("Assets/savedData.txt");
            FileStream fs = fi.Open(FileMode.Open, FileAccess.Read, FileShare.Read);
            StreamReader sr = new StreamReader(fs);
            string fileContent = sr.ReadToEnd();
            //sr.Close();
            //fs.Close();
            Debug.Log(fileContent);
            char[] _fileContent = fileContent.ToCharArray();

            for(int i = 0; i < fileContent.Length; i ++)
            {
                _puzzleValues.Add(fileContent[i]);
            }
        }
        //System.Array.Copy(grid, puzzle, grid.Length);
        _CreateButtons();//Instantiate buttons
        PlayerPrefs.GetInt("_level", 1);
    }
    public void Update()
    {
        _CheckOnEveryFrame();
        try
        {
            for(int k = 0; k < 9; k ++)
            {
                for(int m = 0; m < 9; m ++)
                {
                    if(puzzle[k, m] != 0 && puzzle[k, m] != grid[k, m])
                    {
                        var val = puzzle[k, m];
                        _indicators[val -1].GetComponent<UnityEngine.UI.Image>().color = Color.red;
                    }
                }
            }
        }
        catch{ }
        if(CheckPuzzleUpdate())
        {
            if(_CheckGrid())
            {
                for(int i = 0; i < 9; i ++)
                {
                    //_WaitForSeconds(1);
                    _indicators[i].GetComponent<UnityEngine.UI.Image>().color = Color.green;
                    _winText.SetActive(true);
                }
            }
            else
            {
                if(_winText.activeInHierarchy)
                {
                    _winText.SetActive(false);
                }
            }
        }
    }
    IEnumerator _WaitForSeconds(int seconds)
    {
        yield return new WaitForSeconds(seconds);
    }
    //Checks that if column contains value or not
    public bool _ColumnContainsValue(int col, int value)
    {
        for (int i = 0; i < 9; i++)
        {
            if (grid[i, col] == value)
            {
                return true;
            }
        }

        return false;
    }

    //Checks that if row contains value or not
    public bool _RowContainsValue(int row, int value)
    {
        for (int i = 0; i < 9; i++)
        {
            if (grid[row, i] == value)
            {
                return true;
            }
        }

        return false;
    }

    //Checks that if square contains value or not
    public bool _SquareContainsValue(int row, int col, int value)
    {
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                if(grid[row / 3 * 3 + i, col / 3 * 3 + j] == value)
                    return true;
            }
        }

        return false;
    }

    public void _CreateGrid()
    {
        List<int> rowList = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        List<int> colList = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

        int value = rowList[UnityEngine.Random.Range(0, rowList.Count)];
        grid[0, 0] = value;
        rowList.Remove(value);
        colList.Remove(value);

        for (int i = 1; i < 9; i++)
        {
            value = rowList[UnityEngine.Random.Range(0, rowList.Count)];
            grid[i, 0] = value;
            rowList.Remove(value);
        }

        for (int i = 1; i < 9; i++)
        {
            value = colList[UnityEngine.Random.Range(0, colList.Count)];
            if (i < 3)
            {
                while(_SquareContainsValue(0, 0, value))
                {
                    value = colList[UnityEngine.Random.Range(0, colList.Count)];
                }
            }
            grid[0, i] = value;
            colList.Remove(value);
        }

        for (int i = 6; i < 9; i++)
        {
            value = UnityEngine.Random.Range(1, 10);
            while (_SquareContainsValue(0, 8, value) || _SquareContainsValue(8, 0, value) || _SquareContainsValue(8, 8, value))
            {
                value = UnityEngine.Random.Range(1, 9);
            }
            grid[i, i] = value;
        }

        //ConsoleOutputGrid(grid);
        //for(int i = 0; i<9; i++)
        //{
        //    for(int j = 0; j<9; j++)
        //    {
        //        Debug.Log(i.ToString() + " and " + j.ToString());
        //    }
        //}

        //_CreateLevel();
    }

    public bool _IsValid()
    {
        for(int i = 0; i<9; i++)
        {
            for(int j = 0; j<9; j++)
            {
                if(grid[i,j] == 0)
                    return false;
            }
        }
        return true;
    }

    //Here goes a recursive function call which returns boolean value and this will help in create level
    public bool _CreateLevel()
    {
        int row = 0;
        int col = 0;

        if (_IsValid())
        {
            return true;
        }

        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                if (grid[i, j] == 0)
                {
                    row = i;
                    col = j;
                }
            }
        }

        for (int i = 1; i <= 9; i++)
        {
            if (_CheckAll(row, col, i))
            {
                grid[row, col] = i;

                if (_CreateLevel())
                {
                    return true;
                }
                else
                {
                    grid[row, col] = 0;
                }
            }
        }
        return false;
    }

    //This function checks if the value is presented in that column, row or square
    public bool _CheckAll(int row, int col, int value)
    {
        if (_ColumnContainsValue(col,value)) {
            //Debug.Log(row + " " + col);
            return false;
        }
        if (_RowContainsValue(row, value))
        {
            //Debug.Log(row + " " + col);
            return false;
        }
        if (_SquareContainsValue(row, col, value))
        {
            //Debug.Log(row + " " + col);
            return false;
        }

        return true;
    }

    public void _CreateButtons()
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j = 0; j < 9; j++)
            {
                _nBtn = Instantiate(SudokuCell_Prefab);
                _sCell = _nBtn.GetComponent<SudokuCell>();
                _sCell.SetValues(i, j, puzzle[i, j], /*i + "," + j,*/ this);
                _nBtn.name = i.ToString() + j.ToString();

                if (i < 3)
                {
                    if (j < 3)
                    {
                        _nBtn.transform.SetParent(square00, false);
                    }
                    if (j > 2 && j < 6)
                    {
                        _nBtn.transform.SetParent(square01, false);
                    }
                    if (j >= 6)
                    {
                        _nBtn.transform.SetParent(square02, false);
                    }
                }

                if (i >= 3 && i < 6)
                {
                    if (j < 3)
                    {
                        _nBtn.transform.SetParent(square10, false);
                    }
                    if (j > 2 && j < 6)
                    {
                        _nBtn.transform.SetParent(square11, false);
                    }
                    if (j >= 6)
                    {
                        _nBtn.transform.SetParent(square12, false);
                    }
                }

                if (i >= 6)
                {
                    if (j < 3)
                    {
                        _nBtn.transform.SetParent(square20, false);
                    }
                    if (j > 2 && j < 6)
                    {
                        _nBtn.transform.SetParent(square21, false);
                    }
                    if (j >= 6)
                    {
                        _nBtn.transform.SetParent(square22, false);
                    }
                }
        
            }
        }
    }
    //Script to be called from SudokuCell Script
    public void _UpdatePuzzle(int row, int col, int value)
    {
        puzzle[row, col] = value;
    }

    public void _CheckComplete()
    {

        inputButtons.SetActive(false);
        if (_CheckGrid())
        {
            winMenu.SetActive(true);
            //int _var = PlayerPrefs.GetInt("_level");
            //_var++;
            //PlayerPrefs.SetInt("_level", _var);
        }
        else
        {
            loseText.SetActive(true);
            _Wait();
            Debug.Log("Dear imbecile please try it again :D, PLEASE DO NOT MIND THIS IS ONLY A GAME...");
        }
    }

    public void _Wait()
    {
        StartCoroutine(RemoveAfterSeconds(3, loseText));
    }

    IEnumerator RemoveAfterSeconds(int seconds, GameObject obj)
    {
        yield return new WaitForSeconds(seconds);
        obj.SetActive(false);
    }
    public bool _CheckGrid()
    {
        for (int i = 0; i < 9; i++)
        {
            for (int j =  0; j < 9; j++)
            {
                if (puzzle[i,j] != grid[i,j])
                {
                    return false;
                    
                }
            }
        }
        return true;
    }
    //This is a method responsible to create puzzle
    public void _CreatePuzzle()
    {
        var _d = PlayerPrefs.GetInt("_isLoading");

        if(_d == 0)
        {
            System.Array.Copy(grid, puzzle, grid.Length);
            //Getting level of the player
            var _difficultyLevel = PlayerPrefs.GetInt("_level");
            // Remove cells
            for (int i = 0; i < _difficultyLevel; i++)
            {
                int row = UnityEngine.Random.Range(0, 9);
                int col = UnityEngine.Random.Range(0, 9);

                //while
                _integers.Add(grid[row, col]);
                _cords.Add(row.ToString() + " , " + col.ToString());
                //_config.Add(puzzle[row, col]);
                //dt_config[row, col] = puzzle[row, col];
                puzzle[row, col] = 0;
            }
            //List
        }
        //else
        //{
        //    FileInfo fi = new FileInfo("Assets/savedData.txt");
        //    FileStream fs = fi.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
        //    StreamReader sr = new StreamReader(fs);
        //    string fileContent = sr.ReadToEnd();
        //    sr.Close();
        //    fs.Close();
        //    Debug.Log(fileContent);
        //    var _k = 0;
        //    char[] _fileContent = fileContent.ToCharArray();
        //    for(int i = 0; i < 9; i ++)
        //    {
        //        for(int j = 0; j < 9; j ++)
        //        {
        //            if(_k < _fileContent.Length / 2)
        //            {
        //                puzzle[i ,j] = (int)_fileContent[_k];
        //                _k++;
        //            }
        //            if(_k > _fileContent.Length / 2 && _k < _fileContent.Length)
        //            {
        //                grid[i, j] = (int)_fileContent[_k];
        //                _k++;
        //            }
        //        }
        //    }
        //}
    }

    public void Check(int row, int col)
    {
        if(grid[row, col] != puzzle[row, col])
        {
            Debug.Log("Not Same");
            int value = puzzle[row, col];
            _indicators[value - 1].GetComponent<UnityEngine.UI.Image>().color = Color.red;
            if((value > 1))
            {
                if(_indicators[value - 2].GetComponent<UnityEngine.UI.Image>().color == Color.red)
                    _indicators[value - 2].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
            }
            if(value < 9)
            {
                if(_indicators[value].GetComponent<UnityEngine.UI.Image>().color == Color.red)
                    _indicators[value].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
            }
            for(int i = 0; i < 9; i++)
            {
                if(i != (value - 1))
                {
                    _indicators[i].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
                }
            }
        }
        else
        {
            Debug.Log("Same");
            int value = puzzle[row, col];
            //_indicators[value - 1].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
            AgainCheck(row, col);
        }
    }
    public void AgainCheck(int row, int col)
    {
        for(int i = 0; i < 9; i ++)
        {
            for(int j = 0; j < 9; j ++)
            {
                if(grid[i, j] == puzzle[i, j] && puzzle[i, j] != 0)
                {
                    //var value = puzzle[row, col];
                    //_indicators[value - 1].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
                    for(int k = 0; k < 9; k ++)
                    {
                        _indicators[k].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
                    }
                }
                else
                {
                    if(grid[i, j] != puzzle[i, j] && puzzle[i, j] != 0)
                    {
                        var value = puzzle[row, col];
                        _indicators[value -1].GetComponent<UnityEngine.UI.Image>().color = Color.red;

                        //for(int k = 0; k < 9; k ++)
                        //{
                        //    for(int m = 0; m < 9; m ++)
                        //    {
                        //        if(puzzle[k, m] != 0 && puzzle[k, m] != grid[k, m])
                        //        {
                        //            var val = puzzle[k, m];
                        //            _indicators[val -1].GetComponent<UnityEngine.UI.Image>().color = Color.red;
                        //        }
                        //    }
                        //}

                        for(int k = 0; k < 9; k ++)
                        {
                            if(k != (value -1))
                            {
                                _indicators[k].GetComponent<UnityEngine.UI.Image>().color = Color.blue;
                            }
                        }
                    }
                }
            }
        }
    }

    public bool CheckPuzzleUpdate()
    {
        for(int i = 0; i < 9; i ++)
        {
            for(int j = 0; j < 9; j ++)
            {
                if(puzzle[i, j] == 0)
                {
                    //Debug.Log("Not Completed");
                    return false;
                }
            }
        }
        return true;
    }

    public void _CheckOnEveryFrame()
    {
        for(int k = 1; k <= 9; k ++)
        {
            var _count = 0;
            for(int i = 0; i < 9; i ++)
            {
                for(int j = 0; j < 9; j ++)
                {
                    //Something has to be done as a 2d array
                    if(puzzle[i, j] == k)
                    {
                        _count++;
                    }
                }
            }
            if(_count == 9)
            {
                _indicators[k - 1].GetComponent<UnityEngine.UI.Image>().color = Color.green;
            }
        }
    }

    public void _On_Click_Save()
    {
        using(var sw = new StreamWriter("Assets/savedData.txt"))
        {
            for(int i = 0; i < 9; i ++)
            {
                for(int j = 0; j < 9; j ++)
                {
                    sw.Write(puzzle[i, j]);
                    //sw.Write("\n");
                }
            }
            //sw.Write("\n");
            //for(int i = 0; i < 9; i ++)
            //{
            //    for(int j = 0; j < 9; j ++)
            //    {
            //        sw.Write(grid[i, j]);
            //    }
            //}
        }

        FileInfo fi = new FileInfo("Assets/savedData.txt");
        FileStream fs = fi.Open(FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.ReadWrite);
        //StreamWriter sw = new StreamWriter(fs);
        //for(int i = 0; i < 9; i ++)
        //{
        //    for(int j = 0; j < 9; j ++)
        //    {
        //        sw.Write(puzzle[i, j]);
        //    }
        //}
        StreamReader sr = new StreamReader(fs);
        string fileContent = sr.ReadToEnd();
        sr.Close();
        fs.Close();
        Debug.Log(fileContent);
    }
}
